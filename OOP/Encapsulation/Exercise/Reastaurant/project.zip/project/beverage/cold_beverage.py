from project.beverage.beverage import Beverage


class ColdBeverage(Beverage):
    pass